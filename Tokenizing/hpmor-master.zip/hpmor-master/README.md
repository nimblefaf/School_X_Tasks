# hpmor

This is a plain text version of fanfic Harry Potter and the Methods of
Rationality downloaded from site http://hpmor.com with script [hpmor-dl](https://github.com/bessarabov/hpmor-dl).
